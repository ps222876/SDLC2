<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form method="POST" action="/wachtwoord/nieuw">
        <?php echo csrf_field(); ?>
        <input type="password" name="wachtwoord">
        <button type="submit">Vernieuw wachtwoord</button>
    </form>

    <form method="POST" action="/wachtwoord">
        <?php echo csrf_field(); ?>
        <input type="password" name="wachtwoord">
        <button type="submit">Controleer</button>
        <?php if($correct): ?>
            <div style="color: green">Correct</div>
        <?php else: ?>
            <div style="color: red">Onjuist</div>
        <?php endif; ?>
    </form>

    <div>
        Hash: <?php echo e($hash); ?>

    </div>
</body>

</html>
<?php /**PATH C:\School\Leerjaar2\SDLC\SDLC2\Week5\BCrypt_laravel\resources\views/wachtwoord.blade.php ENDPATH**/ ?>